# Changes in v0.5.0

- Added direct enlarged-space EMRSF (`solve_mrsf_first=False`).
- Added one production flag, `--method mrsf|emrsf`, with `exact-dz` as the
  equal-level default.
- Left `mrsf.py`, `space.py`, and `kernels.py` unchanged from v0.4.1.
- Added a high-accuracy MRSF wrapper that changes only the Davidson residual
  stopping threshold, not the MRSF matrix action.
- Added an exact four-centre, matrix-free MRSF--CV coupling operator.
- Added an independently configurable Davidson residual threshold.
- Added expectation-value closure diagnostics for every EMRSF root.
- Added tighter SCF gradient, direct-SCF, grid, and density-cutoff controls.
- Added controlled MOM-seed projection from cc-pVDZ to larger bases.
- Added `exact-dz`, `tbe-dz`, and `tbe-tz` high-accuracy profiles.
- Added a post-processing comparison against paper values and TBEs.
- Added a strict paired MRSF/EMRSF comparator that checks settings, reference
  energy, AO density, and orbital fingerprint before comparing states.
- Corrected the operational Azulene target mapping to `2 B2` for the supplied
  coordinates.
- No target energy, empirical shift, fitted coupling, or per-molecule parameter
  is used by the Hamiltonian.
