# PySCF-EMRSF v0.3.3

## Scientific correction

- Corrected the EMRSF off-diagonal block to implement the main-text form
  `c_cp C`, with `C_IJ = <Phi_I^MRSF|H|Phi_J^CV>` from SI eq. S39.
- `c_cp` now multiplies the complete Slater--Condon coupling element, including
  both Fock and two-electron terms.  v0.3.2 incorrectly left the Fock pieces
  unscaled while multiplying only the two-electron pieces by `c_H`.
- The paper default remains `c_cp = c_H`; for BH&HLYP this is 0.5.
- The correction is applied identically in the four-index validation builder
  and the RI/matrix-free coupling operator, including the adjoint action.

## Validation additions

- Added the exact zero-coupling limit `C(c_cp=0)=0`.
- Added complete-block linearity checks at fixed orbitals and integrals.
- Added direct equation tests for the G, CO1 (`p=r`), and O2V (`q=s`) entries
  from SI Tables S1--S3.
- Retained the RI-versus-four-index and algebraic-adjoint comparisons.

## Diagnostics and benchmark runner

- Added an optional `EMRSFTDA(..., coupling_scale=...)` diagnostic parameter.
  If omitted, it is taken from the global HF exchange fraction.
- Logs and `.npz` metadata now record `c_H`, `c_cp`, the coupling definition,
  and the MRSF ground offset `A_G`.
- Added `run_azulene_ccp_check.slurm` for the first corrected
  BH&HLYP/cc-pVDZ azulene validation with Molden and NTO exports disabled.
