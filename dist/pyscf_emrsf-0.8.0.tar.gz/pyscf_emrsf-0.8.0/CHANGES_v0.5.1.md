# Changes in v0.5.1

- Added `scf_strategy="standard"|"robust"` to `build_reference`.
- Made the robust reference strategy the default while retaining the original
  one-attempt algorithm through `standard`.
- Added bounded initial CDIIS, ADIIS preconvergence with damping and level
  shifting, exact final-grid MOM refinement, and Newton/CIAH fallback.
- Added explicit period-two density-cycle detection.
- Allowed the average of two oscillating densities only as a retry guess; the
  final reference must remain a converged idempotent restricted open-shell
  determinant.
- Added complete SCF-attempt provenance to result logs and JSON metadata.
- Added separate command-line controls for SCF and response iterations.
- Added an arbitrary-XYZ driver and scratch-staging Slurm script with optional
  OpenQP Molden seeding.
- Added regression tests that force and verify the Newton rescue path.
- Left the MRSF and EMRSF response operators, coupling equations, and Davidson
  implementation unchanged from v0.5.0.
