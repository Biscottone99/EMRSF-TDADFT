# PySCF-EMRSF v0.3.4

## Scope

This is an equation-audit release.  The production/default EMRSF Hamiltonian
is unchanged from v0.3.3: `c_cp=c_H` multiplies the complete coupling block and
the Table-S3 G row retains the `sqrt(2)` spin factor.

## Coupling diagnostics

- Added `analyse_ground_coupling()` to decompose `C.T |MRSF S0>`.
- Separated the matrix-free coupling action into exactly additive Fock and
  two-electron components, with componentwise adjoint tests.
- Added mutually exclusive G, D, OOS, CO1/CO2, O1V/O2V, and CV(MRSF) family
  contributions.
- Added exact EMRSF--MRSF S0 shift, coupling-vector norms, and a clearly
  labeled diagonal-resolvent second-order estimate with interference-aware
  family partitions.
- Added the diagnostic-only `g_spin_factor` parameter.  Its default is
  `sqrt(2)`; changing it affects only the G-row Fock coupling and never changes
  `c_cp` or any other coupling family.

## Runner and output

- Logs and NPZ metadata now record `g_spin_factor`.
- `--coupling-audit` writes all audit quantities to the ORCA-like log and NPZ.
- `--skip-observables` avoids S42--S47 grid work during coupling-only checks;
  density/Molden/NTO calculations remain unchanged when requested normally.
- Added `run_azulene_gfactor_audit.slurm`, which keeps `c_cp=0.5`, tests only
  the candidate G-row factor `2.0`, and prints an automatic comparison with the
  Azulene paper target.

## Validation

- Added explicit checks that Fock plus two-electron actions reconstruct the
  original RI operator and that each component satisfies its own adjoint.
- Added a four-index/RI comparison for non-default G-row factors.
- Added family-partition and diagonal-shift sum rules.
- Full local suite: 27 tests.
