# Changes in PySCF-EMRSF 0.8.0

- Added `compute_emrsf_soc(singlets, triplets, two_electron=...)`.
- EMRSF SOC now contracts the spin-orbit operator with EMRSF-TDA eigenvectors
  and includes the added closed-shell LR-CV configurations.
- Preserved separate state-interaction matrices for the one-electron
  Breit-Pauli and mean-field two-electron SOC contributions.
- Retained the existing `none`, `amfi`, and `full` two-electron choices.
- Explicitly projected the unresolved four-open MRSF C->V auxiliary-wavefunction
  sector and added per-state excluded-weight diagnostics.
- Added the included LR-CV weight for every singlet and triplet root.
- Added complete, configuration-labelled eigenvector CSV files and bumped the
  lossless post-processing archive format to version 3.
- Expanded SOC archives with raw singlet/triplet response vectors, basis maps,
  determinant coefficients, MO/AO SOC integrals, orbital data, and geometry.
- Added `compute_external_soc(...)` and the `--soc-external-module` callback
  interface.
- Added `examples/xyz_job/external_soc_module_example.py`.
- Updated the XYZ driver so `--method emrsf --soc` uses EMRSF roots instead of
  the companion MRSF roots.

Scientific status: the SOC implementation is an explicitly defined
EMRSF-TDA auxiliary-wavefunction state interaction. It is not presented as an
analytic quadratic-response property. The added LR-CV sector is included; the
four-open MRSF C->V sector is not assigned unpublished spin-completion phases.

