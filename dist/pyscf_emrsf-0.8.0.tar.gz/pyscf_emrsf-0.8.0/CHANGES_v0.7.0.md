# Changes in PySCF-EMRSF 0.7.0

- Added `target_multiplicity=3` to `EMRSFTDA`.
- Added the triplet LR-TDA exchange-only response kernel for global hybrids.
- Added the `(L+R)/sqrt(2)` OOS row and complete `S1+S2` triplet MRSF--CV
  coupling in direct four-centre and density-fitted implementations.
- Kept `mrsf.py`, `space.py`, and `kernels.py` byte-identical to v0.6.0.
- Generalised logs and post-processing metadata to record target multiplicity.
- Added explicit same-manifold and common-singlet-S0 energy columns to state
  CSV files. Vertical triplet benchmarks use `common_s0_excitation_ev`.
- Enabled `--method emrsf --states triplets|both` in the XYZ driver. A
  triplet-only request automatically solves a one-root singlet S0 anchor.
- SOC remains based on the corresponding MRSF companion states because a full
  EMRSF SOC transition density is not defined.
- Added five external MP2/6-31G* geometries and nine CC3/TZVP triplet targets
  from Schreiber *et al.*, plus batch and comparison scripts.
- Added equation-level and packaging tests for the triplet extension.

Scientific boundary: singlet EMRSF is the published method of Oh *et al.*;
triplet EMRSF in this release is a derived extension. No reference energy was
used to tune a parameter or alter the MRSF operator.
