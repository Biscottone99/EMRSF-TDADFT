# PySCF-EMRSF v0.3.2

This release corrects the state-correlation report and adds opt-in orbital
visualization artifacts without changing the matrix-free Hamiltonian.

## State correlation

- MRSF and EMRSF roots are correlated by identical spectroscopic term.
- A low conditional overlap is flagged but does not redirect a term to another
  root.
- A term absent from the computed MRSF window is reported as `UNMATCHED`.
- The `.npz` stores accepted state indices, best-overlap candidates, status,
  overlaps, and `NaN` energy shifts for unmatched terms.

## Optional files

- `--write-molden` writes the converged triplet-reference orbitals.
- `--write-nto` writes MRSF S0-to-Sn NTO Molden files and `nto_summary.csv`.
- Both flags default to false and are omitted from `run_all.slurm`.
- `--nto-weight-threshold` defaults to `1e-4`; `--nto-max-pairs` can impose an
  additional per-transition limit.
