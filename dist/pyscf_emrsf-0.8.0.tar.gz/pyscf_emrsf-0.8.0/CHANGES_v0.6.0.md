# PySCF-EMRSF 0.6.0

Version 0.6.0 adds multi-manifold, PCM and SOC workflows while preserving the
v0.5.2 MRSF/EMRSF operators.

## New calculation controls

- `--method mrsf|emrsf` selects conventional or extended MRSF.
- `--states singlets|triplets|both` computes either or both spin manifolds.
- EMRSF remains the published singlet extension. Triplets requested alongside
  EMRSF are calculated and labelled as MRSF-TDA.
- `--response tda` records the validated response formulation explicitly.
- Oscillator strengths are automatic; `--no-oscillator-strengths` is the
  opt-out flag.

## PCM

- `PCMConfig` attaches C-PCM, COSMO, IEF-PCM or SS(V)PE to every reference-SCF
  attempt, including robust retries.
- The dielectric, cavity discretization, radii scale and convergence settings
  are exposed by the XYZ and Slurm drivers.
- The converged reaction potential is included in both spin Fock matrices and
  in the EMRSF LR Fock block.
- Solvent response is deliberately frozen during excitation: no unpublished
  MRSF excited-state PCM kernel is claimed.

## SOC-MRSF

- Singlet and all three triplet Ms components are expanded into the explicit
  spin-adapted MRSF configuration-state functions of Komarov et al.
- Breit-Pauli one-electron SOC is always available.
- Two-electron screening can be disabled or evaluated with AMFI-SOMF or full
  SOMF.
- CV configurations are excluded from SOC transition densities according to
  the published time-reversal prescription, and their excluded weights are
  retained in the NPZ archive.
- The complex Hermitian state-interaction matrix, S/T couplings in cm-1,
  SOC-adiabatic energies and eigenvectors are written to log, CSV and NPZ.

## Optical output

- Every MRSF singlet or triplet log contains length-gauge transition dipoles
  and oscillator strengths from the lowest state of that manifold.
- EMRSF logs contain explicitly labelled companion-MRSF optical values; full
  EMRSF oscillator strengths are not claimed because the published equations
  lack the required enlarged-space transition-density blocks.
