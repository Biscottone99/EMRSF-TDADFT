# PySCF-EMRSF v0.3.6

This is an equation-audit release. It does not fit a continuous parameter and
does not promote the Azulene `O2V=-1` candidate to the production default.

## LR-CV diagonal decomposition

- Stores the uncorrected closed-shell Fock matrix and the orbital-resolved
  diagonal correction of SI eq. S30 separately.
- Adds `CorrectedLRTDA.diagonal_components()`, which decomposes every added
  C->V diagonal into raw Fock, S30, Coulomb, global exact exchange, and the
  residual semilocal XC kernel.
- Evaluates response densities in bounded AO batches so that the audit remains
  compatible with the matrix-free benchmark path.
- Adds `analyse_lr_cv_diagonal()`. It appends `A_G` once, recomputes its MRSF
  source matrix element, and verifies representative diagonals through the
  complete EMRSF `matvec`.
- Writes the complete decomposition and independent closure checks to the log
  and stores all arrays in the NPZ archive.

## Corrected coupling diagnostic

The ground-state second-order coupling audit now uses the complete diagonal of
`A_CV + A_G`, including the LR Coulomb, exact-exchange, and XC-kernel response.
Earlier releases used only the Fock-difference Davidson preconditioner in this
diagnostic. The production EMRSF Hamiltonian and its eigenvalues were not
affected by that diagnostic-only omission.

## Azulene workflow

- Adds `run_azulene_lr_cv_audit.slurm` for the current discrete candidate
  `CO1=+1`, `O2V=-1`, with `c_cp=0.5` and `g_spin_factor=2.0` held fixed.
- Adds `summarize_azulene_lr_cv_audit.py`, which reports the S0 and target-state
  diagonal expectations and the dominant target CV configurations.
- Reference-orbital Molden and MRSF NTO exports remain opt-in and disabled in
  the diagnostic Slurm script.

