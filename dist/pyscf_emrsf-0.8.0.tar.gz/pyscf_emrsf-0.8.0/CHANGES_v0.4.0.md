# PySCF-EMRSF v0.4.0

- Fixed incomplete Davidson starting spaces. Both MRSF and EMRSF now seed
  every Abelian irrep in addition to global diagonal oversampling.
- Added per-irrep seed diagnostics to logs and NPZ archives.
- Constructed `A_G` explicitly from SI eq. S23 and retained the MRSF `G,G`
  element as an independent equality check.
- Corrected SI eq. S45: both centroids now use the common S44 charge `q`.
- Fixed Table-S3 `sqrt(2)` and Table-S1-minus-Table-S2 conventions in the
  public API; removed empirical G-factor and CO1/O2V phase switches.
- Removed the invalid global B1/B2 conversion from the benchmark parser.
- Clarified that ordinal term matching and overlap matching are diagnostics,
  not a paper-defined automatic root-tracking prescription.
- Added regression tests for an initially absent symmetry block, S23, S45,
  RI adjoints, explicit SI coupling elements, and dense/iterative equivalence.
