# PySCF-EMRSF v0.3.5

## Scope

This is a relative-phase audit release for the remaining Azulene mismatch.
It does not select a new production Hamiltonian. The retained defaults are
`co1_phase=+1` and `o2v_phase=+1`, so default calculations remain identical to
v0.3.4. The Azulene audit keeps `c_cp=0.5` and explicitly requests the
diagnostic G-row factor `2.0` established in the preceding check.

## Diagnostic coupling phases

- Added `co1_phase` and `o2v_phase`, each restricted to exactly `+1` or `-1`.
- Each phase multiplies the complete coupling rows of its MRSF configuration
  family, including both Fock and two-electron contributions.
- The same phase is applied in the direct and transpose matrix-free actions,
  preserving a real symmetric EMRSF block Hamiltonian.
- Dense four-index and RI implementations expose the same controls.

These switches test whether the SI coupling equations were combined with an
inconsistent relative configuration phase. They are not continuous fitting
parameters. A phase choice must not be promoted to the production default
without an equation-level derivation.

## Runner and output

- `run_case.py` accepts `--co1-phase` and `--o2v-phase`.
- ORCA-like logs, coupling audits, JSON metadata, and NPZ fields record both
  phases.
- `run_azulene_phase_audit.slurm` runs the four sign combinations as a Slurm
  array while leaving S42--S47, Molden, and NTO exports disabled.
- `compare_azulene_phase_audit.py` combines the four NPZ files, reports the
  closest energy and gamma separately, and deliberately uses no fitted score.

## Validation

- Added family-isolation tests for both phase switches.
- Added dense/RI agreement and componentwise adjoint tests with both phases
  inverted.
- Added invalid-phase checks and log/audit propagation checks.
