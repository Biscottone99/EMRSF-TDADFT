# PySCF-EMRSF 0.5.2

Version 0.5.2 adds reproducible post-processing and optical-property output
without changing the MRSF or EMRSF response operators.

- Complete MRSF and EMRSF eigenvectors are saved in compressed, pickle-free
  NPZ archives together with configuration maps, orbital coefficients,
  orbital energies and occupations, Fock matrices, symmetry labels, molecular
  construction data, AO overlap and AO position integrals.
- Every archive has a JSON manifest defining shapes, indexing and basis order.
- The XYZ driver now activates the already implemented SI S42--S47 analysis
  through `--write-observables` and writes `q`, `D_CT` and `q D_CT` to both log
  and CSV.
- `--write-oscillator-strengths` evaluates MRSF state-to-state transition
  dipoles and length-gauge oscillator strengths.
- The production Slurm enables observables, oscillator strengths and vector
  archives by default; each output can be independently disabled through its
  environment variable.

Scientific scope: the published EMRSF equations do not specify all LR--LR and
MRSF--LR transition-density blocks. Consequently, optical and S42--S47
properties are explicitly labelled MRSF properties. Full enlarged-space EMRSF
coefficients are saved, but the package does not present an incomplete
projected quantity as a full EMRSF oscillator strength.
