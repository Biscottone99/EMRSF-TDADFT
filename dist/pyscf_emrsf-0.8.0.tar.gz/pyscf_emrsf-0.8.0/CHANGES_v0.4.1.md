# PySCF-EMRSF 0.4.1

- Added strict automatic, Molden-seeded MOM, and fixed-external triplet
  reference workflows.
- Added cross-overlap AO projection and metric repair for OpenQP Molden files.
- Added reference provenance, electron/spin traces, orbital gradients, SOMO
  and occupied-subspace overlaps, frontier gaps, and symmetry-purity output.
- Rejected unlocked benchmark references for N-phenylpyrrole and twisted
  DMABN unless explicitly requested as a negative control.
- Separated SCF/response and S42--S47 quadrature-grid command-line options.
- Replaced forced C2v input with point-group auto-detection and purity checks.
- Corrected the bundled paper target table with geometry-specific B1/B2
  mappings for azulene and quinoxaline.
- Added fixed-reference OpenQP MRSF regressions and OpenQP input generation for
  the complete five-molecule set.
- Extended coupling tests to every branch of SI Tables S1--S3 against explicit
  four-index MO integrals.
- Removed obsolete 0.4.0 Slurm scripts that would fail the version guard.
- Kept Molden and MRSF-NTO exports opt-in; no unsupported full-EMRSF density or
  NTO formula was introduced.
